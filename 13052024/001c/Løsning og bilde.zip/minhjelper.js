
// alle objekter hentes fra document


//document.getElementById
//document.querySelector(selectors)

//const parentDOM = document.getElementById("parent-id");
//const test1 = parentDOM.getElementById("test1");

const labelR1 = document.getElementById("labelR1");
