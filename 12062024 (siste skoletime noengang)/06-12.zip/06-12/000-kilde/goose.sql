CREATE TABLE goosoner (
  ID INTEGER PRIMARY KEY,
  FN TEXT NOT NULL,
  LN TEXT NOT NULL,
  age INTEGER NOT NULL  
);

INSERT INTO goosoner (FN, LN, age) VALUES 
('Billy', 'The Kid', 14), 
('Didric', 'NoFly', 22), 
('Messy', 'Leonora', 19);

